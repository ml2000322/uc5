package br.com.sistemacomercial.view;

public class TelaCadastroProduto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
