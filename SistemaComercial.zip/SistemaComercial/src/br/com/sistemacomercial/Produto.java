package br.com.sistemacomercial;

public class Produto {

}
